function triggerDownload(filename) {
  // Simulate download trigger — replace with real asset link if needed
  alert(`Summoning artifact: ${filename}`);
}
